alfa19 <-
function(data,alpha){
  
library(gtools)
C<-matrix(0,ncol=dim(data)[1],nrow=dim(data)[1])

for(i in 1:dim(data)[1]){
   for(j in 1:dim(data)[1]){
    if(i<j){
    C[i,j]=sum(as.numeric(data[i,]==data[j,]))
}else
 C[i,j]=sum(as.numeric(data[i,]==data[j,]))
}
C[i,i]=dim(data)[2]
  }


C_prima<-dim(data)[2]-C

M<-dim(data)[2]

#enlace<-2*C-M
#enlace<-enlace-diag(diag(enlace))

enlace<-C
enlace<-enlace-diag(diag(enlace))

enlace2<-enlace

grupos<-list()
#alpha2<-alpha
A<-dim(data)[1]
B<-1:dim(data)[1]
suma<-1

while(A>alpha && suma!=0){

k<-numeric(dim(data)[1])
 for(j in 1:dim(data)[1]){
 k[j]<-max(enlace[,j])
  }

#tengo que cambiar ese A por un B
 if(A==dim(data)[1]){
  ini<-which.max(k)

}else{

k[ab]=0

 ini<-which.max(k)
}

 







  posicion<-which.max(enlace[ini,])
  a<-enlace[ini,posicion]
 
  di<-which(enlace[ini,]==a)



 
  enlace[ini,posicion]=0
  posicion_columna<-which.max(enlace[,posicion])
  b<-enlace[posicion_columna,posicion]
  enlace[ini,posicion]<-a






















 if(a>b){


if(length(di)>1){

     if(dim(data)[1]==A){

     grupos[[1]]<-c(ini,posicion)
     ab<-unlist(grupos)
     largo<-length(B[-ab])
     A<-length(grupos)+largo
     enlace[,posicion]=0
     enlace[posicion,]=0
    }else{

      
     
      grupos[[length(grupos)+1]]<-c(ini,posicion)

   
      ab<-unlist(grupos)
      dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

           if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo


         }else{

         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo}

        }else{

         largo<-length(B[-ab])
         A<-length(grupos)+largo



      }
     

      enlace[,posicion]=0
      enlace[posicion,]=0

 }

    di2<-which(enlace[ini,]==a)

     for(j in 1:length(di2)){


       if(A>alpha){

     posicion<-which.max(enlace[ini,])
     a2<-enlace[ini,posicion]
     enlace[ini,posicion]=0
     posicion_columna<-which.max(enlace[,posicion])
     b2<-enlace[posicion_columna,posicion]
     enlace[ini,posicion]<-a2

      if(a2>=b2){
       enlace[,posicion]=0
       enlace[posicion,]=0
       grupos[[length(grupos)+1]]<-c(ini,posicion)

        
        ab<-unlist(grupos)
        dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
       
        if(length(dup)>=2){


     if(length(dup)==4){
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
             
 
             ab<-unlist(grupos)
             dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo

       
      }else{



         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        }


     

       } #termina el if(a>=b)
}


 } #termina el if(A>alpha)

} # aca termina el for


    

 #aca terminar el if(length)>=2
 }else{


  


 if(dim(data)[1]==A){

  grupos[[1]]<-c(ini,posicion)
  ab<-unlist(grupos)
  largo<-length(B[-ab])
  A<-length(grupos)+largo
  enlace[,posicion]=0
  enlace[posicion,]=0
 }else{

   grupos[[length(grupos)+1]]<-c(ini,posicion)

   enlace[,posicion]=0
   enlace[posicion,]=0

    
    ab<-unlist(grupos)
    dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

        if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo



         }else{



         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        } 

       
         




     } #termina if(lengt(dup)>=2)

        largo<-length(B[-ab])
         A<-length(grupos)+largo
    
  
} #termina el else de  if(dim(data)[1]==A)

  



}


}


 #fin del if(a>b)





if(a==b){


if(length(di)>1){

     if(dim(data)[1]==A){

     grupos[[1]]<-c(ini,posicion)
     ab<-unlist(grupos)
     largo<-length(B[-ab])
     A<-length(grupos)+largo
     enlace[,posicion]=0
     enlace[posicion,]=0
    }else{

      
     
      grupos[[length(grupos)+1]]<-c(ini,posicion)

      ab<-unlist(grupos)
      dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

           if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo


         }else{

         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))   
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo}

        }else{

         largo<-length(B[-ab])
         A<-length(grupos)+largo



      }
     




      enlace[,posicion]=0
      enlace[posicion,]=0




 }

    di2<-which(enlace[ini,]==a)

     for(j in 1:length(di2)){
    

     
     if(A>alpha){

     posicion<-which.max(enlace[ini,])
     a2<-enlace[ini,posicion]
     enlace[ini,posicion]=0
     posicion_columna<-which.max(enlace[,posicion])
     b2<-enlace[posicion_columna,posicion]
     enlace[ini,posicion]<-a2

      if(a2>=b2){
       enlace[,posicion]=0
       enlace[posicion,]=0
       grupos[[length(grupos)+1]]<-c(ini,posicion)

        
        ab<-unlist(grupos)
        dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
        
        if(length(dup)>=2){


      if(length(dup)==4){
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
             
 
             ab<-unlist(grupos)
             dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo

       
      }else{


         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        }

       } #termina el if(a>=b)

}


    
} #termina if(A>alpha)

} #termina el for

 #aca terminar el if(length)>=2
 }else{


  


 if(dim(data)[1]==A){

  grupos[[1]]<-c(ini,posicion)
  ab<-unlist(grupos)
  largo<-length(B[-ab])
  A<-length(grupos)+largo
  enlace[,posicion]=0
  enlace[posicion,]=0
 }else{

   grupos[[length(grupos)+1]]<-c(ini,posicion)

   enlace[,posicion]=0
   enlace[posicion,]=0

 
    ab<-unlist(grupos)
    dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

        if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo



         }else{



         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        }

       
         




     }  #termina el if(length(dup)>=2)


         largo<-length(B[-ab])
         A<-length(grupos)+largo
    
  
} #termina el else de  if(dim(data)[1]==A)

  



}


}

# termina el if(a==b)



if(a<b){


if(length(di)>1){

     if(dim(data)[1]==A){

     grupos[[1]]<-c(ini,posicion)
     ab<-unlist(grupos)
     largo<-length(B[-ab])
     A<-length(grupos)+largo
     enlace[,posicion]=0
     enlace[posicion,]=0
    }else{

      
     
      grupos[[length(grupos)+1]]<-c(ini,posicion)

   
      ab<-unlist(grupos)
      dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

           if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo


         }else{

         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo}

        }else{

         largo<-length(B[-ab])
         A<-length(grupos)+largo



      }
     




      enlace[,posicion]=0
      enlace[posicion,]=0




 }

    di2<-which(enlace[ini,]==a)

     for(j in 1:length(di2)){


       if(A>alpha){

     posicion<-which.max(enlace[ini,])
     a2<-enlace[ini,posicion]
     enlace[ini,posicion]=0
     posicion_columna<-which.max(enlace[,posicion])
     b2<-enlace[posicion_columna,posicion]
     enlace[ini,posicion]<-a2

      if(a2>=b2){
       enlace[,posicion]=0
       enlace[posicion,]=0
       grupos[[length(grupos)+1]]<-c(ini,posicion)

        
        ab<-unlist(grupos)
        dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
       
        if(length(dup)>=2){


     if(length(dup)==4){
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
             
 
             ab<-unlist(grupos)
             dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
             ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
             grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
             grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo

       
      }else{



         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        }


     

       } #termina el if(a>=b)
}


 } #termina el if(A>alpha)

} # aca termina el for


    

 #aca terminar el if(length)>=2
 }else{


  


 if(dim(data)[1]==A){

  grupos[[1]]<-c(ini,posicion)
  ab<-unlist(grupos)
  largo<-length(B[-ab])
  A<-length(grupos)+largo
  enlace[,posicion]=0
  enlace[posicion,]=0
 }else{

   grupos[[length(grupos)+1]]<-c(ini,posicion)

   enlace[,posicion]=0
   enlace[posicion,]=0

    
    ab<-unlist(grupos)
    dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]

        if(length(dup)>=2){

        if(length(dup)==4){
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo
            

            ab<-unlist(grupos)
            dup<-ab[!(!duplicated(ab) & rev(!duplicated(rev(ab))))]
            ak<-which(sapply(grupos, function(e) is.element(dup[1], e)))
            grupos[[ak[1]]]<-unique(unlist(grupos[ak]))
            grupos[[ak[2]]]<-NULL
             largo<-length(B[-ab])
             A<-length(grupos)+largo



         }else{



         az<-which(sapply(grupos, function(e) is.element(dup[1], e)))  
         grupos[[az[1]]]<-unique(unlist(grupos[az]))
         grupos[[az[length(az)]]]<-NULL  
         largo<-length(B[-ab])
         A<-length(grupos)+largo

        } 

       
         




     } #termina if(lengt(dup)>=2)

        largo<-length(B[-ab])
         A<-length(grupos)+largo
    
  
} #termina el else de  if(dim(data)[1]==A)

  



}


}


 #fin del if(a<b)





k<-numeric(dim(data)[1])
 for(j in 1:dim(data)[1]){
 k[j]<-max(enlace[,j])
  }

ab<-unlist(grupos)
k[ab]=0

largo<-length(B[-ab])



if(sum(k)==0 || largo==0){



 suma<-0



}else{


suma<-sum(k)

}

k2<-length(k[k!=0])

if(k2==1){

suma<-0


}



} # Termina el while







while(A>alpha && suma==0){


ab3<-length(unlist(grupos))


 

if(ab3==dim(data)[1]){



af2<-1:length(grupos)

combinaciones<-list()

combi <- combinations(length(af2), 2, af2)

for(an in 1:dim(combi)[1]){

combinaciones[[an]]<-combi[an,]

}









Calidad_c<-rep(0,length(combinaciones))

for(kp in 1:length(Calidad_c)){

grupos2<-grupos
grupos2[[length(grupos2)+1]]<-unlist(grupos2[combinaciones[[kp]]])

grupos2[combinaciones[[kp]]]<-NULL

       

class_C<-numeric()

for(n in 1:length(grupos2)){
class_C[grupos2[[n]]]<-n
}





Y_c<-matrix(0,ncol=dim(data)[1],nrow=dim(data)[1])
for(i in 1:dim(data)[1]){
   for(j in 1:dim(data)[1]){
Y_c[i,j]=ifelse(class_C[i]==class_C[j],1,0)
 
}}



Y_c1<-(1-Y_c)
C1<-(dim(data)[2]-C)
Calidad_c[kp]<-sum(C*Y_c+C1*Y_c1)


} # termina el for kp



max_calidad<-which.max(Calidad_c)

posi_calidad<-unlist(combinaciones[max_calidad])
grupos[[posi_calidad[1]]]<-unlist(grupos[posi_calidad])
grupos[posi_calidad[2]]<-NULL





ab<-unlist(grupos)
largo<-length(B[-ab])
A<-length(grupos)+largo


}else{
ab<-unlist(grupos)
largo2<-B[-ab]

grupos[[length(grupos)+1]]<-largo2

af2<-1:length(grupos)

combinaciones<-list()

combi <- combinations(length(af2), 2, af2)

for(an in 1:dim(combi)[1]){

combinaciones[[an]]<-combi[an,]

}






Calidad_c<-rep(0,length(combinaciones))

for(kp in 1:length(Calidad_c)){

grupos2<-grupos
grupos2[[length(grupos2)+1]]<-unlist(grupos2[combinaciones[[kp]]])

grupos2[combinaciones[[kp]]]<-NULL

       

class_C<-numeric()

for(n in 1:length(grupos2)){
class_C[grupos2[[n]]]<-n
}




Y_c<-matrix(0,ncol=dim(data)[1],nrow=dim(data)[1])
for(i in 1:dim(data)[1]){
   for(j in 1:dim(data)[1]){
Y_c[i,j]=ifelse(class_C[i]==class_C[j],1,0)
 
}}



Y_c1<-(1-Y_c)
C1<-(dim(data)[2]-C)
Calidad_c[kp]<-sum(C*Y_c+C1*Y_c1)


} # termina el for kp


max_calidad<-which.max(Calidad_c)

posi_calidad<-unlist(combinaciones[max_calidad])
grupos[[posi_calidad[1]]]<-unlist(grupos[posi_calidad])
grupos[posi_calidad[2]]<-NULL



ab<-unlist(grupos)
largo<-length(B[-ab])
A<-length(grupos)+largo


}#termina el else de if(ab3==dim(data)[1]). Falta colocar un for


} #termina el while


z<-list()
z<-grupos


ab<-unlist(grupos)
ac<-B[-ab]

if(length(grupos)==alpha){

   z<-grupos


}else{

for(i in 1:length(ac)){

  z[[length(grupos)+i]]<-ac[i]


}
}


return(z)

}
