#' @title Dataset Felinos
#' 
#' @description Datos de ejemplo para utilizar alfa19
#' @format Un data.frame con:
#' \describe{
#'   \item{columna1}{Característica 1}
#'   \item{columna2}{Característica 2 }
#' }
#' @source Datos Simulados internamente
"Felinos"